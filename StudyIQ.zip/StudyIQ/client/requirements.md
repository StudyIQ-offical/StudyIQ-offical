## Packages
framer-motion | Smooth animations for chat messages and page transitions
date-fns | Date formatting for chat timestamps

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Outfit'", "sans-serif"],
  body: ["'DM Sans'", "sans-serif"],
}
